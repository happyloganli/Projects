package Test;

import model.Customer;

import java.util.Date;

public class Tester {
    public static void main(String[] args) {
        Date today = new Date();

        System.out.println(today);
    }
}
